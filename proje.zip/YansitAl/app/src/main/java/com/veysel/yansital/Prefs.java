package com.veysel.yansital;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Random;

final class Prefs {
    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("yansital", Context.MODE_PRIVATE);
    }

    static String name(Context c) {
        String n = p(c).getString("name", null);
        if (n == null || n.trim().isEmpty()) n = "TV " + Build.MODEL;
        return n.replace("|", " ").trim();
    }

    static void setName(Context c, String n) {
        p(c).edit().putString("name", n.trim()).apply();
    }

    static int code(Context c) {
        int k = p(c).getInt("code", 0);
        if (k < 1000 || k > 9999) k = newCode(c);
        return k;
    }

    static int newCode(Context c) {
        int k = 1000 + new Random().nextInt(9000);
        p(c).edit().putInt("code", k).apply();
        return k;
    }

    static String lastIp(Context c) {
        return p(c).getString("lastIp", "");
    }

    static String lastCode(Context c) {
        return p(c).getString("lastCode", "");
    }

    static void setLast(Context c, String ip, String code) {
        p(c).edit().putString("lastIp", ip).putString("lastCode", code).apply();
    }

    static int quality(Context c) {
        return p(c).getInt("quality", 1080);
    }

    static void setQuality(Context c, int q) {
        p(c).edit().putInt("quality", q).apply();
    }
}
