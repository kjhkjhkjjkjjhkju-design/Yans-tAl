package com.veysel.yansital;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** TV tarafı: bağlantıyı kabul eder, H.264'ü çözüp ekrana, PCM sesi hoparlöre verir. */
final class Receiver {

    interface Events {
        void onClient(String name);

        void onVideoSize(int w, int h);

        void onDisconnected();
    }

    private final Context ctx;
    private final Events ev;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean run = false;
    private volatile Surface surface;
    private volatile Socket cur;
    private volatile DataOutputStream curOut;
    private ServerSocket server;

    Receiver(Context c, Events e) {
        ctx = c.getApplicationContext();
        ev = e;
    }

    void setSurface(Surface s) {
        surface = s;
    }

    void start() {
        if (run) return;
        run = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop();
            }
        }, "yansital-accept").start();
    }

    void stop() {
        run = false;
        disconnectClient();
        try {
            if (server != null) server.close();
        } catch (Exception ignored) {
        }
    }

    /** TV'den durdurma: telefona "bitir" der, bağlantıyı kapatır. */
    void disconnectClient() {
        final Socket s = cur;
        final DataOutputStream o = curOut;
        if (s == null) return;
        cur = null;
        curOut = null;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (o != null) {
                        synchronized (o) {
                            o.writeByte(Proto.BACK_STOP);
                            o.flush();
                        }
                    }
                } catch (Exception ignored) {
                }
                closeQuiet(s);
            }
        }, "yansital-bye").start();
        main.post(new Runnable() {
            @Override
            public void run() {
                ev.onDisconnected();
            }
        });
    }

    private static void closeQuiet(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (Exception ignored) {
        }
    }

    private void acceptLoop() {
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(Proto.TCP_PORT));
            while (run) {
                Socket s = server.accept();
                handshake(s);
            }
        } catch (Exception ignored) {
        }
    }

    private void handshake(final Socket s) {
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(3000);
            final DataInputStream in = new DataInputStream(s.getInputStream());
            final DataOutputStream out = new DataOutputStream(s.getOutputStream());
            int magic = in.readInt();
            int code = in.readInt();
            final String name = in.readUTF();
            if (magic != Proto.MAGIC) {
                s.close();
                return;
            }
            Socket old = cur;
            cur = s;
            curOut = out;
            closeQuiet(old);
            out.writeByte(Proto.R_OK);
            out.writeUTF(Prefs.name(ctx));
            out.flush();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    session(s, in, out, name);
                }
            }, "yansital-session").start();
        } catch (Exception e) {
            closeQuiet(s);
        }
    }

    private void requestKey(DataOutputStream out) {
        try {
            synchronized (out) {
                out.writeByte(Proto.BACK_KEYFRAME);
                out.flush();
            }
        } catch (Exception ignored) {
        }
    }

    private void session(final Socket s, final DataInputStream in, final DataOutputStream out, final String name) {
        VideoDecoder dec = null;
        AudioOut aud = new AudioOut();
        aud.start();
        main.post(new Runnable() {
            @Override
            public void run() {
                ev.onClient(name);
            }
        });
        // Telefona saniyede bir "buradayım" der; kopmayı iki taraf da fark eder.
        Thread hb = new Thread(new Runnable() {
            @Override
            public void run() {
                while (run && cur == s && !s.isClosed()) {
                    try {
                        synchronized (out) {
                            out.writeByte(Proto.BACK_PING);
                            out.flush();
                        }
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        break;
                    }
                }
            }
        }, "yansital-hb");
        hb.start();
        try {
            s.setSoTimeout(5000);
            boolean gotKey = false;
            byte[] buf = new byte[1 << 20];
            while (run) {
                int type = in.readUnsignedByte();
                int len = in.readInt();
                if (len < 0 || len > (16 << 20)) break;
                if (buf.length < len) buf = new byte[len];
                in.readFully(buf, 0, len);
                if (type == Proto.T_CONFIG && len > 4) {
                    final int w = ((buf[0] & 0xff) << 8) | (buf[1] & 0xff);
                    final int h = ((buf[2] & 0xff) << 8) | (buf[3] & 0xff);
                    if (dec != null) dec.release();
                    dec = null;
                    gotKey = false;
                    Surface sf = surface;
                    if (sf != null && sf.isValid()) {
                        VideoDecoder d = new VideoDecoder();
                        if (d.start(sf, w, h, buf, 4, len - 4)) dec = d;
                    }
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            ev.onVideoSize(w, h);
                        }
                    });
                } else if (type == Proto.T_VIDEO && len > 1) {
                    if (dec == null) continue;
                    boolean key = buf[0] == 1;
                    if (!key && !gotKey) {
                        requestKey(out);
                        continue;
                    }
                    if (key) gotKey = true;
                    if (!dec.feed(buf, 1, len - 1, 0)) {
                        // çözücü yetişemedi: bu kareyi at, yeni anahtar kare iste
                        gotKey = false;
                        requestKey(out);
                    }
                } else if (type == Proto.T_AUDIO && len > 0) {
                    aud.write(buf, 0, len);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (dec != null) dec.release();
            aud.stop();
            closeQuiet(s);
            if (cur == s) {
                cur = null;
                curOut = null;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        ev.onDisconnected();
                    }
                });
            }
        }
    }

    // ------------------------------------------------------------ video

    private static final class VideoDecoder {
        private MediaCodec c;
        private volatile boolean alive = true;

        boolean start(Surface s, int w, int h, byte[] cfg, int off, int len) {
            try {
                MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
                f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 20);
                f.setInteger(MediaFormat.KEY_PRIORITY, 0);
                f.setInteger(MediaFormat.KEY_OPERATING_RATE, 60);
                if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
                c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                c.configure(f, s, null, 0);
                c.start();
                feed(cfg, off, len, MediaCodec.BUFFER_FLAG_CODEC_CONFIG);
                final MediaCodec cc = c;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                        while (alive) {
                            try {
                                int i = cc.dequeueOutputBuffer(info, 10000);
                                if (i >= 0) cc.releaseOutputBuffer(i, true);
                            } catch (Exception e) {
                                break;
                            }
                        }
                    }
                }, "yansital-dec").start();
                return true;
            } catch (Exception e) {
                release();
                return false;
            }
        }

        boolean feed(byte[] b, int off, int len, int flags) {
            try {
                int i = c.dequeueInputBuffer(8000);
                if (i < 0) return false;
                ByteBuffer ib = c.getInputBuffer(i);
                if (ib == null || ib.capacity() < len) {
                    c.queueInputBuffer(i, 0, 0, 0, 0);
                    return false;
                }
                ib.clear();
                ib.put(b, off, len);
                c.queueInputBuffer(i, 0, len, System.nanoTime() / 1000, flags);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        void release() {
            alive = false;
            if (c == null) return;
            try {
                c.stop();
            } catch (Exception ignored) {
            }
            try {
                c.release();
            } catch (Exception ignored) {
            }
            c = null;
        }
    }

    // -------------------------------------------------------------- ses

    private static final class AudioOut {
        private AudioTrack t;
        private final ArrayBlockingQueue<byte[]> q = new ArrayBlockingQueue<>(12);
        private volatile boolean alive = true;

        void start() {
            try {
                int min = AudioTrack.getMinBufferSize(Proto.AUDIO_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
                int size = Math.max(min, Proto.AUDIO_RATE * 4 / 12);
                t = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(Proto.AUDIO_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                                .build())
                        .setBufferSizeInBytes(size)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                        .build();
                t.play();
                final AudioTrack tt = t;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (alive) {
                            try {
                                byte[] d = q.poll(200, TimeUnit.MILLISECONDS);
                                if (d != null) tt.write(d, 0, d.length);
                            } catch (Exception e) {
                                break;
                            }
                        }
                    }
                }, "yansital-aout").start();
            } catch (Throwable e) {
                t = null;
            }
        }

        void write(byte[] b, int off, int len) {
            if (t == null) return;
            if (q.size() > 6) {
                while (q.size() > 2) q.poll(); // geride kaldı: yetiş
            }
            byte[] d = Arrays.copyOfRange(b, off, off + len);
            while (!q.offer(d)) q.poll();
        }

        void stop() {
            alive = false;
            if (t == null) return;
            try {
                t.stop();
            } catch (Exception ignored) {
            }
            try {
                t.release();
            } catch (Exception ignored) {
            }
            t = null;
        }
    }
}
