package com.veysel.yansital;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Surface;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Telefon tarafı: ekranı (MediaProjection) H.264 olarak, sesi ham PCM olarak TV'ye yollar.
 * Ağ tıkanırsa kare atar + bitrate düşürür, bağlantı koparsa kendiliğinden yeniden bağlanır,
 * ekran dönünce kodlayıcıyı yeni boyutla yeniden kurar.
 */
public class CastService extends Service {
    static final String ACTION_STOP = "com.veysel.yansital.STOP";

    /** 0 boşta, 1 bağlanıyor, 2 yayında, 3 yeniden bağlanıyor */
    static volatile int state = 0;
    static volatile String tvName = "";
    static volatile String lastError = null;

    private static final class Pkt {
        final byte[] b;
        final boolean video;

        Pkt(byte[] b, boolean video) {
            this.b = b;
            this.video = video;
        }
    }

    private final AtomicBoolean closing = new AtomicBoolean(false);
    private volatile boolean running = false;
    private volatile boolean connected = false;
    private volatile boolean waitKey = true;

    private String ip;
    private int port, code;
    private int maxLong, maxBitrate, minBitrate;
    private volatile int curBitrate;
    private int curW, curH, dpi;
    private volatile long lastCongestion = 0, lastKeyReq = 0;

    private MediaProjection projection;
    private VirtualDisplay vd;
    private DisplayManager dm;
    private DisplayManager.DisplayListener dl;
    private WifiManager.WifiLock wifiLock;
    private HandlerThread ctl;
    private Handler ctlH;

    private final Object encLock = new Object();
    private MediaCodec enc;
    private Surface encSurface;

    private Thread sendThread, netThread, audioThread;
    private volatile Socket sock;
    private volatile OutputStream sockOut;
    private volatile byte[] cachedConfig;
    private final LinkedBlockingQueue<Pkt> q = new LinkedBlockingQueue<>();

    private final Runnable rotRun = new Runnable() {
        @Override
        public void run() {
            reconfig();
        }
    };

    private final Runnable raiser = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (connected && SystemClock.elapsedRealtime() - lastCongestion > 6000 && curBitrate < maxBitrate) {
                curBitrate = Math.min(maxBitrate, (int) (curBitrate * 1.1f));
                applyBitrate();
            }
            ctlH.postDelayed(this, 3000);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || running) return START_NOT_STICKY;
        startFg();
        ip = intent.getStringExtra("ip");
        port = intent.getIntExtra("port", Proto.TCP_PORT);
        code = intent.getIntExtra("code", 0);
        int quality = intent.getIntExtra("quality", 1080);
        int rc = intent.getIntExtra("rc", 0);
        Intent data = intent.getParcelableExtra("data");

        lastError = null;
        tvName = "";
        state = 1;
        closing.set(false);
        running = true;
        maxLong = quality >= 1080 ? 1920 : 1280;
        maxBitrate = quality >= 1080 ? 9000000 : 5000000;
        minBitrate = 1500000;
        curBitrate = (int) (maxBitrate * 0.85f);
        try {
            setup(rc, data);
        } catch (Throwable t) {
            fail("Başlatılamadı: " + t.getMessage());
        }
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("cast", "Ekran yansıtma", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, CastService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "cast")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Ekran TV'ye yansıtılıyor")
                .setContentText("Durdurmak için dokun")
                .setOngoing(true)
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Durdur", pi).build())
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, n);
        }
    }

    private void setup(int rc, Intent data) throws Exception {
        ctl = new HandlerThread("yansital-ctl");
        ctl.start();
        ctlH = new Handler(ctl.getLooper());

        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiLock = wm.createWifiLock(Build.VERSION.SDK_INT >= 29
                ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "yansital");
        wifiLock.acquire();

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(rc, data);
        if (projection == null) throw new IllegalStateException("ekran izni alınamadı");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                ctlH.post(new Runnable() {
                    @Override
                    public void run() {
                        shutdown();
                        stopSelf();
                    }
                });
            }
        }, ctlH);

        dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        int[] sz = computeSize();
        curW = sz[0];
        curH = sz[1];
        startEncoder(curW, curH);
        vd = projection.createVirtualDisplay("yansital", curW, curH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, encSurface, null, null);
        MediaCodec c;
        synchronized (encLock) {
            c = enc;
        }
        drain(c, curW, curH);

        dl = new DisplayManager.DisplayListener() {
            @Override
            public void onDisplayAdded(int id) {
            }

            @Override
            public void onDisplayRemoved(int id) {
            }

            @Override
            public void onDisplayChanged(int id) {
                if (id == Display.DEFAULT_DISPLAY && ctlH != null) {
                    ctlH.removeCallbacks(rotRun);
                    ctlH.postDelayed(rotRun, 200);
                }
            }
        };
        dm.registerDisplayListener(dl, ctlH);

        sendThread = new Thread(new Runnable() {
            @Override
            public void run() {
                sendLoop();
            }
        }, "yansital-send");
        sendThread.start();
        netThread = new Thread(new Runnable() {
            @Override
            public void run() {
                netLoop();
            }
        }, "yansital-net");
        netThread.start();
        startAudio();
        ctlH.postDelayed(raiser, 3000);
    }

    // ---------------------------------------------------------------- görüntü

    private static int r16(float v) {
        return Math.max(16, Math.round(v / 16f) * 16);
    }

    private int[] computeSize() {
        DisplayMetrics m = new DisplayMetrics();
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealMetrics(m);
        dpi = m.densityDpi;
        float s = (float) maxLong / Math.max(m.widthPixels, m.heightPixels);
        if (s > 1f) s = 1f;
        return new int[]{r16(m.widthPixels * s), r16(m.heightPixels * s)};
    }

    private void startEncoder(int w, int h) throws Exception {
        MediaCodec c = null;
        Surface s = null;
        Exception last = null;
        for (int attempt = 0; attempt < 3 && c == null; attempt++) {
            MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            f.setInteger(MediaFormat.KEY_BIT_RATE, curBitrate);
            f.setInteger(MediaFormat.KEY_FRAME_RATE, 60);
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            f.setInteger(MediaFormat.KEY_PRIORITY, 0);
            f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500000L);
            f.setInteger("prepend-sps-pps-to-idr-frames", 1);
            if (attempt == 0) {
                f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR);
                f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline);
            } else if (attempt == 1) {
                f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline);
            }
            if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
            MediaCodec t = null;
            try {
                t = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                t.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                s = t.createInputSurface();
                t.start();
                c = t;
            } catch (Exception e) {
                last = e;
                if (t != null) {
                    try {
                        t.release();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        if (c == null) throw last != null ? last : new IllegalStateException("kodlayıcı açılamadı");
        synchronized (encLock) {
            enc = c;
            encSurface = s;
        }
    }

    private void drain(final MediaCodec c, final int w, final int h) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (running) {
                    int i;
                    try {
                        i = c.dequeueOutputBuffer(info, 20000);
                    } catch (Exception e) {
                        break;
                    }
                    if (i < 0) continue;
                    try {
                        ByteBuffer bb = c.getOutputBuffer(i);
                        if (bb != null && info.size > 0) {
                            bb.position(info.offset);
                            bb.limit(info.offset + info.size);
                            if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                byte[] d = new byte[info.size + 4];
                                d[0] = (byte) (w >> 8);
                                d[1] = (byte) w;
                                d[2] = (byte) (h >> 8);
                                d[3] = (byte) h;
                                bb.get(d, 4, info.size);
                                onConfig(Proto.pack(Proto.T_CONFIG, d));
                            } else {
                                boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                                byte[] r = new byte[6 + info.size];
                                r[0] = Proto.T_VIDEO;
                                Proto.putInt(r, 1, info.size + 1);
                                r[5] = (byte) (key ? 1 : 0);
                                bb.get(r, 6, info.size);
                                onVideo(r, key);
                            }
                        }
                    } catch (Exception ignored) {
                    }
                    try {
                        c.releaseOutputBuffer(i, false);
                    } catch (Exception e) {
                        break;
                    }
                }
            }
        }, "yansital-enc");
        t.start();
    }

    private void onConfig(byte[] pkt) {
        cachedConfig = pkt;
        if (connected) {
            waitKey = true;
            q.offer(new Pkt(pkt, false));
        }
    }

    private int videoCount() {
        int n = 0;
        for (Pkt p : q) if (p.video) n++;
        return n;
    }

    private void onVideo(byte[] pkt, boolean key) {
        if (!connected) return;
        long now = SystemClock.elapsedRealtime();
        if (key) {
            if (videoCount() > 2) {
                for (Pkt p : q) if (p.video) q.remove(p);
            }
            waitKey = false;
        } else if (waitKey) {
            if (now - lastKeyReq > 500) requestKey();
            return;
        } else if (videoCount() > 5) {
            // ağ yetişemiyor: kare at, bitrate düşür, yeni anahtar kare iste
            waitKey = true;
            congestion();
            return;
        }
        q.offer(new Pkt(pkt, true));
    }

    private void congestion() {
        lastCongestion = SystemClock.elapsedRealtime();
        curBitrate = Math.max(minBitrate, (int) (curBitrate * 0.75f));
        applyBitrate();
        requestKey();
    }

    private void applyBitrate() {
        Bundle b = new Bundle();
        b.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, curBitrate);
        synchronized (encLock) {
            if (enc != null) {
                try {
                    enc.setParameters(b);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void requestKey() {
        lastKeyReq = SystemClock.elapsedRealtime();
        Bundle b = new Bundle();
        b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
        synchronized (encLock) {
            if (enc != null) {
                try {
                    enc.setParameters(b);
                } catch (Exception ignored) {
                }
            }
        }
    }

    /** Ekran döndü: kodlayıcıyı yeni boyutla kur, TV yeni çözücü açsın. */
    private void reconfig() {
        if (!running || vd == null) return;
        try {
            int[] s = computeSize();
            if (s[0] == curW && s[1] == curH) return;
            MediaCodec old;
            Surface oldS;
            synchronized (encLock) {
                old = enc;
                oldS = encSurface;
                enc = null;
                encSurface = null;
            }
            startEncoder(s[0], s[1]);
            MediaCodec n;
            Surface ns;
            synchronized (encLock) {
                n = enc;
                ns = encSurface;
            }
            vd.setSurface(ns);
            vd.resize(s[0], s[1], dpi);
            curW = s[0];
            curH = s[1];
            drain(n, curW, curH);
            if (old != null) {
                try {
                    old.stop();
                } catch (Exception ignored) {
                }
                try {
                    old.release();
                } catch (Exception ignored) {
                }
            }
            if (oldS != null) oldS.release();
        } catch (Exception e) {
            fail("Ekran döndürme sırasında hata: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------- ses

    private void startAudio() {
        if (Build.VERSION.SDK_INT < 29) return;
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Proto.AUDIO_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            int min = AudioRecord.getMinBufferSize(Proto.AUDIO_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            final AudioRecord rec = new AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min, Proto.AUDIO_CHUNK * 4))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            rec.startRecording();
            audioThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] buf = new byte[Proto.AUDIO_CHUNK];
                    while (running) {
                        int n = rec.read(buf, 0, buf.length);
                        if (n < 0) break;
                        if (n == 0) continue;
                        if (connected && q.size() < 100) {
                            q.offer(new Pkt(Proto.pack(Proto.T_AUDIO, Arrays.copyOf(buf, n)), false));
                        }
                    }
                    try {
                        rec.stop();
                    } catch (Exception ignored) {
                    }
                    rec.release();
                }
            }, "yansital-aud");
            audioThread.start();
        } catch (Throwable t) {
            // ses yakalanamadı: görüntü yine de gider
        }
    }

    // ----------------------------------------------------------------- ağ

    private void sendLoop() {
        while (running) {
            Pkt p;
            try {
                p = q.poll(1000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                break;
            }
            OutputStream o = sockOut;
            if (o == null || !connected) continue;
            try {
                byte[] b = p != null ? p.b : Proto.pack(Proto.T_PING, new byte[0]);
                o.write(b);
            } catch (Exception e) {
                closeQuiet(sock);
            }
        }
    }

    private void netLoop() {
        boolean everConnected = false;
        long lastOk = SystemClock.elapsedRealtime();
        while (running) {
            Socket s = new Socket();
            boolean bad = false;
            boolean stopReq = false;
            try {
                s.setTcpNoDelay(true);
                s.setSendBufferSize(131072);
                s.connect(new InetSocketAddress(ip, port), 3000);
                s.setSoTimeout(5000);
                DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                DataInputStream dis = new DataInputStream(s.getInputStream());
                dos.writeInt(Proto.MAGIC);
                dos.writeInt(code);
                dos.writeUTF(Build.MODEL);
                dos.flush();
                int res = dis.readUnsignedByte();
                if (res == Proto.R_BAD_CODE) {
                    bad = true;
                    throw new IOException("kod");
                }
                if (res != Proto.R_OK) throw new IOException("red");
                tvName = dis.readUTF();
                q.clear();
                sock = s;
                sockOut = s.getOutputStream();
                waitKey = true;
                connected = true;
                state = 2;
                everConnected = true;
                lastOk = SystemClock.elapsedRealtime();
                byte[] cfg = cachedConfig;
                if (cfg != null) q.offer(new Pkt(cfg, false));
                requestKey();
                while (running) {
                    int b = dis.readUnsignedByte();
                    lastOk = SystemClock.elapsedRealtime();
                    if (b == Proto.BACK_KEYFRAME) {
                        requestKey();
                    } else if (b == Proto.BACK_STOP) {
                        stopReq = true;
                        break;
                    }
                }
            } catch (Exception ignored) {
            } finally {
                connected = false;
                sock = null;
                sockOut = null;
                closeQuiet(s);
            }
            if (bad) {
                fail("TV kodu reddetti. TV'deki kodu kontrol et.");
                return;
            }
            if (stopReq) {
                fail("TV yayını sonlandırdı.");
                return;
            }
            if (!running) break;
            long away = SystemClock.elapsedRealtime() - lastOk;
            if (away > (everConnected ? 120000 : 30000)) {
                fail(everConnected ? "Bağlantı kesildi." : "TV'ye bağlanılamadı. Aynı Wi-Fi'da mısınız, adres ve kod doğru mu?");
                return;
            }
            state = everConnected ? 3 : 1;
            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    private static void closeQuiet(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------- kapatma

    private void fail(String msg) {
        lastError = msg;
        shutdown();
        stopSelf();
    }

    private void shutdown() {
        if (!closing.compareAndSet(false, true)) return;
        running = false;
        connected = false;
        try {
            if (dl != null && dm != null) dm.unregisterDisplayListener(dl);
        } catch (Exception ignored) {
        }
        closeQuiet(sock);
        if (sendThread != null) sendThread.interrupt();
        if (netThread != null) netThread.interrupt();
        synchronized (encLock) {
            if (enc != null) {
                try {
                    enc.stop();
                } catch (Exception ignored) {
                }
                try {
                    enc.release();
                } catch (Exception ignored) {
                }
                enc = null;
            }
            if (encSurface != null) {
                encSurface.release();
                encSurface = null;
            }
        }
        if (vd != null) {
            try {
                vd.release();
            } catch (Exception ignored) {
            }
            vd = null;
        }
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
            }
            projection = null;
        }
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        if (ctlH != null) ctlH.removeCallbacksAndMessages(null);
        if (ctl != null) ctl.quitSafely();
        q.clear();
        state = 0;
        stopForeground(true);
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }
}
