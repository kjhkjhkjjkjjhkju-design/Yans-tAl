package com.veysel.yansital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** TV tarafı: alıcı ekranı. Uygulama kapanınca hiçbir şey çalışmaz. */
public class ReceiveActivity extends Activity {
    private FrameLayout root;
    private SurfaceView sv;
    private LinearLayout overlay;
    private TextView nameT, ipT, statusT;
    private Receiver receiver;
    private Discovery.Responder responder;
    private WifiManager.WifiLock lock;
    private boolean streaming = false;
    private int vw = 0, vh = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        sv = new SurfaceView(this);
        root.addView(sv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = UI.dp(this, 32);
        overlay.setPadding(p, p, p, p);
        overlay.setBackground(UI.rect(this, UI.BG, 22, 0, 0));

        TextView mode = UI.text(this, "AL MODU", 14, UI.TEAL, true);
        nameT = UI.text(this, "", 30, UI.TEXT, true);
        TextView addrLabel = UI.text(this, "Telefonda girilecek adres", 15, UI.SUB, false);
        addrLabel.setPadding(0, UI.dp(this, 18), 0, 0);
        ipT = UI.text(this, "", 40, UI.TEAL, true);
        statusT = UI.text(this, "", 16, UI.TEXT, false);
        statusT.setPadding(0, UI.dp(this, 16), 0, UI.dp(this, 16));

        overlay.addView(mode);
        overlay.addView(nameT);
        overlay.addView(addrLabel);
        overlay.addView(ipT);
        overlay.addView(statusT);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView rename = UI.button(this, "Adı değiştir", UI.FIELD, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rename();
            }
        });
        row.addView(rename, UI.lp(this, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0f, 6));
        overlay.addView(row);

        TextView hint = UI.text(this, "Telefonda: Yansıt Al → Yansıt → bu TV'yi seç (ya da adresi yaz)", 13, UI.SUB, false);
        hint.setPadding(0, UI.dp(this, 16), 0, 0);
        overlay.addView(hint);

        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(overlay, olp);
        setContentView(root);
        rename.requestFocus();

        sv.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                if (receiver != null) receiver.setSurface(holder.getSurface());
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                if (receiver != null) receiver.setSurface(holder.getSurface());
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                if (receiver != null) receiver.setSurface(null);
            }
        });

        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int bt, int ol, int ot, int or, int ob) {
                if ((r - l) != (or - ol) || (bt - t) != (ob - ot)) applyAspect();
            }
        });

        receiver = new Receiver(this, new Receiver.Events() {
            @Override
            public void onClient(String name) {
                streaming = true;
                statusT.setText("Bağlandı: " + name);
                overlay.setVisibility(View.GONE);
            }

            @Override
            public void onVideoSize(int w, int h) {
                vw = w;
                vh = h;
                applyAspect();
            }

            @Override
            public void onDisconnected() {
                streaming = false;
                vw = 0;
                vh = 0;
                applyAspect();
                statusT.setText("Telefonun bağlanmasını bekliyor…");
                overlay.setVisibility(View.VISIBLE);
            }
        });
    }

    private void refreshInfo() {
        nameT.setText(Prefs.name(this));
        ipT.setText(Discovery.localIp());
    }

    private void applyAspect() {
        int rw = root.getWidth();
        int rh = root.getHeight();
        FrameLayout.LayoutParams lp;
        if (vw > 0 && vh > 0 && rw > 0 && rh > 0) {
            float s = Math.min((float) rw / vw, (float) rh / vh);
            lp = new FrameLayout.LayoutParams(Math.round(vw * s), Math.round(vh * s), Gravity.CENTER);
        } else {
            lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        }
        sv.setLayoutParams(lp);
    }

    private void rename() {
        final EditText e = new EditText(this);
        e.setText(Prefs.name(this));
        e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("TV adı")
                .setView(e)
                .setPositiveButton("Kaydet", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = e.getText().toString().trim();
                        if (!n.isEmpty()) {
                            Prefs.setName(ReceiveActivity.this, n);
                            refreshInfo();
                        }
                    }
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        refreshInfo();
        statusT.setText("Telefonun bağlanmasını bekliyor…");
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        lock = wm.createWifiLock(Build.VERSION.SDK_INT >= 29
                ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "yansital-tv");
        lock.acquire();
        responder = new Discovery.Responder(this);
        responder.start();
        receiver.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        receiver.stop();
        if (responder != null) {
            responder.shutdown();
            responder = null;
        }
        if (lock != null && lock.isHeld()) lock.release();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onBackPressed() {
        if (streaming) {
            receiver.disconnectClient();
        } else {
            super.onBackPressed();
        }
    }
}
