package com.veysel.yansital;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashSet;
import java.util.Set;

/** Telefon tarafı: TV'yi seç, kodu gir, yansıtmayı başlat. */
public class SendActivity extends Activity {
    private static final int REQ_CAP = 100;
    private static final int REQ_AUDIO = 101;

    private EditText ipField, codeField;
    private TextView status, startBtn, q720, q1080, scanText;
    private LinearLayout list;
    private Discovery.Finder finder;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Set<String> seen = new HashSet<>();
    private int quality;
    private int shownState = -1;
    private String pendingIp = "";
    private int pendingPort = Proto.TCP_PORT;
    private int pendingCode;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(UI.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(this, 20);
        root.setPadding(pad, pad, pad, pad);
        sc.addView(root);

        root.addView(UI.text(this, "Yansıt", 30, UI.TEXT, true));
        TextView hint = UI.text(this, "TV'de uygulamayı aç ve \"Al\" seç. Sonra aşağıdan TV'yi seç, ekrandaki kodu gir.", 14, UI.SUB, false);
        hint.setPadding(0, UI.dp(this, 4), 0, UI.dp(this, 18));
        root.addView(hint);

        root.addView(label("Bulunan TV'ler"));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        scanText = UI.text(this, "Aranıyor…", 14, UI.SUB, false);
        scanText.setPadding(0, UI.dp(this, 6), 0, UI.dp(this, 6));
        root.addView(scanText);

        root.addView(label("Adres (otomatik dolar, gerekirse elle yaz)"));
        ipField = field("örn. 192.168.1.25");
        ipField.setKeyListener(DigitsKeyListener.getInstance("0123456789."));
        ipField.setText(Prefs.lastIp(this));
        root.addView(ipField);

        root.addView(label("TV'de görünen 4 haneli kod"));
        codeField = field("0000");
        codeField.setInputType(InputType.TYPE_CLASS_NUMBER);
        codeField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        codeField.setText(Prefs.lastCode(this));
        root.addView(codeField);

        root.addView(label("Kalite"));
        LinearLayout qrow = new LinearLayout(this);
        qrow.setOrientation(LinearLayout.HORIZONTAL);
        q720 = UI.button(this, "720p  akıcı", UI.FIELD, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setQuality(720);
            }
        });
        q1080 = UI.button(this, "1080p  net", UI.FIELD, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setQuality(1080);
            }
        });
        qrow.addView(q720, UI.lp(this, 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, 4));
        qrow.addView(q1080, UI.lp(this, 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, 4));
        root.addView(qrow);
        quality = Prefs.quality(this) >= 1080 ? 1080 : 720;
        setQuality(quality);

        startBtn = UI.button(this, "Yansıtmayı Başlat", UI.ACCENT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStartClick();
            }
        });
        LinearLayout.LayoutParams sp = UI.lp(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0f, 4);
        sp.topMargin = UI.dp(this, 20);
        root.addView(startBtn, sp);

        status = UI.text(this, "", 14, UI.SUB, false);
        status.setPadding(UI.dp(this, 4), UI.dp(this, 10), 0, 0);
        root.addView(status);

        setContentView(sc);
    }

    private TextView label(String t) {
        TextView v = UI.text(this, t, 13, UI.SUB, true);
        v.setPadding(0, UI.dp(this, 14), 0, UI.dp(this, 6));
        return v;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(UI.TEXT);
        e.setHintTextColor(UI.SUB);
        e.setTextSize(18);
        int p = UI.dp(this, 14);
        e.setPadding(p, p, p, p);
        e.setBackground(UI.rect(this, UI.FIELD, 12, 0, 0));
        return e;
    }

    private void setQuality(int q) {
        quality = q;
        Prefs.setQuality(this, q);
        q720.setBackground(UI.focusable(this, q == 720 ? UI.ACCENT : UI.FIELD, 14));
        q1080.setBackground(UI.focusable(this, q == 1080 ? UI.ACCENT : UI.FIELD, 14));
    }

    private void onFound(final String name, final String ip, final int port) {
        if (!seen.add(ip)) return;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 14);
        row.setPadding(p, p, p, p);
        row.setBackground(UI.focusable(this, UI.CARD, 12));
        row.setFocusable(true);
        row.addView(UI.text(this, name, 18, UI.TEXT, true));
        row.addView(UI.text(this, ip, 13, UI.SUB, false));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ipField.setText(ip);
                pendingPort = port;
                String lc = Prefs.lastCode(SendActivity.this);
                if (ip.equals(Prefs.lastIp(SendActivity.this)) && !lc.isEmpty()) codeField.setText(lc);
                codeField.requestFocus();
            }
        });
        list.addView(row, UI.lp(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0f, 4));
        scanText.setText("Seçmek için dokun");
    }

    private void onStartClick() {
        if (CastService.state != 0) {
            Intent i = new Intent(this, CastService.class);
            i.setAction(CastService.ACTION_STOP);
            startService(i);
            return;
        }
        String ip = ipField.getText().toString().trim();
        String c = codeField.getText().toString().trim();
        if (ip.isEmpty() || c.length() != 4) {
            status.setTextColor(UI.RED);
            status.setText("Adresi ve TV'deki 4 haneli kodu gir.");
            return;
        }
        pendingIp = ip;
        pendingCode = Integer.parseInt(c);
        Prefs.setLast(this, ip, c);
        if (Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        askCapture();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req == REQ_AUDIO) askCapture(); // ses izni verilmese de görüntü yansıtılır
    }

    private void askCapture() {
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAP);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAP) return;
        if (res == RESULT_OK && data != null) {
            Intent i = new Intent(this, CastService.class);
            i.putExtra("rc", res);
            i.putExtra("data", data);
            i.putExtra("ip", pendingIp);
            i.putExtra("port", pendingPort);
            i.putExtra("code", pendingCode);
            i.putExtra("quality", quality);
            startForegroundService(i);
            moveTaskToBack(true);
        } else {
            status.setTextColor(UI.RED);
            status.setText("Ekran yakalama izni verilmedi.");
        }
    }

    private void refresh() {
        int s = CastService.state;
        String err = CastService.lastError;
        if (s != shownState) {
            shownState = s;
            if (s == 0) {
                startBtn.setText("Yansıtmayı Başlat");
                startBtn.setBackground(UI.focusable(this, UI.ACCENT, 14));
            } else {
                startBtn.setText("Yansıtmayı Durdur");
                startBtn.setBackground(UI.focusable(this, 0xFFD64545, 14));
            }
        }
        if (s == 0) {
            if (err != null) {
                status.setTextColor(UI.RED);
                status.setText(err);
            } else {
                status.setTextColor(UI.SUB);
                status.setText("Hazır");
            }
        } else if (s == 1) {
            status.setTextColor(UI.SUB);
            status.setText("TV'ye bağlanılıyor…");
        } else if (s == 2) {
            status.setTextColor(UI.TEAL);
            status.setText("Yansıtılıyor → " + CastService.tvName);
        } else {
            status.setTextColor(UI.SUB);
            status.setText("Bağlantı koptu, yeniden deneniyor…");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        seen.clear();
        list.removeAllViews();
        scanText.setText("Aranıyor…");
        finder = new Discovery.Finder(this, new Discovery.Listener() {
            @Override
            public void onFound(String name, String ip, int port) {
                SendActivity.this.onFound(name, ip, port);
            }
        });
        finder.start();
        shownState = -1;
        h.post(poll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (finder != null) {
            finder.shutdown();
            finder = null;
        }
        h.removeCallbacks(poll);
    }
}
