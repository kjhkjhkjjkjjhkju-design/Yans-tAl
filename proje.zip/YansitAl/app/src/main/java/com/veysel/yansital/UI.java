package com.veysel.yansital;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Küçük arayüz yardımcıları (XML yok, hafif kalsın diye). */
final class UI {
    private UI() {}

    static final int BG = 0xFF0B0F14;
    static final int CARD = 0xFF151C26;
    static final int FIELD = 0xFF1C2532;
    static final int ACCENT = 0xFF4F8CFF;
    static final int TEAL = 0xFF00C2A8;
    static final int TEXT = 0xFFFFFFFF;
    static final int SUB = 0xFF8A97A8;
    static final int RED = 0xFFFF6B6B;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int color, float rDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, rDp));
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke);
        return g;
    }

    /** Odaklanınca (kumanda) beyaz çerçeve, basınca hafif koyu. */
    static StateListDrawable focusable(Context c, int color, float rDp) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, rect(c, color, rDp, 0xFFFFFFFF, 3));
        s.addState(new int[]{android.R.attr.state_pressed}, rect(c, (color & 0x00FFFFFF) | 0xAA000000, rDp, 0, 0));
        s.addState(new int[]{}, rect(c, color, rDp, 0, 0));
        return s;
    }

    static TextView text(Context c, String t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    static TextView button(Context c, String label, int color, View.OnClickListener l) {
        TextView v = text(c, label, 16, TEXT, true);
        v.setGravity(Gravity.CENTER);
        int p = dp(c, 14);
        v.setPadding(dp(c, 20), p, dp(c, 20), p);
        v.setBackground(focusable(c, color, 14));
        v.setFocusable(true);
        v.setOnClickListener(l);
        return v;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float weight, int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        int m = dp(c, marginDp);
        p.setMargins(m, m, m, m);
        return p;
    }
}
