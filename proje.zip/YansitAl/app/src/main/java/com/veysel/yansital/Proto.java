package com.veysel.yansital;

/** Telefon ile TV arasındaki basit protokol. */
final class Proto {
    private Proto() {}

    static final int MAGIC = 0x59414E53;
    static final int TCP_PORT = 53000;
    static final int UDP_PORT = 53001;

    // Telefon -> TV paket türleri
    static final byte T_CONFIG = 1;
    static final byte T_VIDEO = 2;
    static final byte T_AUDIO = 3;
    static final byte T_PING = 4;

    // El sıkışma cevabı
    static final int R_OK = 1;
    static final int R_BAD_CODE = 2;

    // TV -> telefon
    static final int BACK_PING = 0;
    static final int BACK_KEYFRAME = 1;
    static final int BACK_STOP = 2;

    // Ses: ham PCM, 48 kHz, stereo, 16 bit (20 ms = 3840 bayt)
    static final int AUDIO_RATE = 48000;
    static final int AUDIO_CHUNK = 3840;

    static final String PROBE = "YANSITAL?";
    static final String REPLY = "YANSITAL!";

    static void putInt(byte[] b, int o, int v) {
        b[o] = (byte) (v >>> 24);
        b[o + 1] = (byte) (v >>> 16);
        b[o + 2] = (byte) (v >>> 8);
        b[o + 3] = (byte) v;
    }

    static byte[] pack(byte type, byte[] payload) {
        byte[] r = new byte[5 + payload.length];
        r[0] = type;
        putInt(r, 1, payload.length);
        System.arraycopy(payload, 0, r, 5, payload.length);
        return r;
    }
}
