package com.veysel.yansital;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final boolean tv = getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(UI.BG);
        int pad = UI.dp(this, tv ? 48 : 24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = UI.text(this, "Yansıt Al", tv ? 40 : 34, UI.TEXT, true);
        title.setGravity(Gravity.CENTER);
        TextView sub = UI.text(this, "Telefon ekranını TV'ye düşük gecikmeyle aktar", tv ? 18 : 15, UI.SUB, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, UI.dp(this, 6), 0, UI.dp(this, tv ? 32 : 24));
        root.addView(title);
        root.addView(sub);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(tv ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);

        View send = card("Yansıt", "Bu cihazın ekranını TV'ye gönder", UI.ACCENT, tv, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SendActivity.class));
            }
        });
        View recv = card("Al", "Bu cihaz alıcı olsun, yansıtılan ekranı göstersin", UI.TEAL, tv, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ReceiveActivity.class));
            }
        });

        if (tv) {
            row.addView(recv, UI.lp(this, 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, 12));
            row.addView(send, UI.lp(this, 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f, 12));
            recv.requestFocus();
        } else {
            row.addView(send, UI.lp(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0f, 8));
            row.addView(recv, UI.lp(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0f, 8));
        }
        root.addView(row);
        setContentView(root);
    }

    private View card(String title, String desc, int accent, boolean tv, View.OnClickListener l) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, tv ? 28 : 20);
        c.setPadding(p, p, p, p);
        c.setBackground(UI.focusable(this, UI.CARD, 18));
        c.setFocusable(true);
        c.setOnClickListener(l);
        c.addView(UI.text(this, title, tv ? 32 : 26, accent, true));
        TextView d = UI.text(this, desc, tv ? 17 : 14, UI.SUB, false);
        d.setPadding(0, UI.dp(this, 6), 0, 0);
        c.addView(d);
        return c;
    }
}
