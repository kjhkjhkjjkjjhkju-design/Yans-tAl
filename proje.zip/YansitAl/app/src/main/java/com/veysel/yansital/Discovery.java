package com.veysel.yansital;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Aynı ağdaki TV'leri UDP yayını ile bulma. */
final class Discovery {
    private Discovery() {}

    interface Listener {
        void onFound(String name, String ip, int port);
    }

    /** TV tarafı: "YANSITAL?" sorusuna adını ve portunu söyler. */
    static final class Responder extends Thread {
        private final Context ctx;
        private volatile boolean run = true;
        private DatagramSocket sock;

        Responder(Context c) {
            ctx = c.getApplicationContext();
            setName("yansital-resp");
        }

        @Override
        public void run() {
            try {
                sock = new DatagramSocket(null);
                sock.setReuseAddress(true);
                sock.bind(new InetSocketAddress(Proto.UDP_PORT));
                byte[] buf = new byte[256];
                while (run) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    sock.receive(p);
                    String s = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    if (s.startsWith(Proto.PROBE)) {
                        String r = Proto.REPLY + "|" + Prefs.name(ctx) + "|" + Proto.TCP_PORT;
                        byte[] rb = r.getBytes(StandardCharsets.UTF_8);
                        sock.send(new DatagramPacket(rb, rb.length, p.getAddress(), p.getPort()));
                    }
                }
            } catch (Exception ignored) {
            }
        }

        void shutdown() {
            run = false;
            if (sock != null) sock.close();
        }
    }

    /** Telefon tarafı: yayın atar, cevap verenleri listeler. */
    static final class Finder extends Thread {
        private final Context ctx;
        private final Listener listener;
        private final Handler main = new Handler(Looper.getMainLooper());
        private volatile boolean run = true;

        Finder(Context c, Listener l) {
            ctx = c.getApplicationContext();
            listener = l;
            setName("yansital-find");
        }

        @Override
        public void run() {
            DatagramSocket s = null;
            try {
                s = new DatagramSocket();
                s.setBroadcast(true);
                s.setSoTimeout(300);
                byte[] probe = Proto.PROBE.getBytes(StandardCharsets.UTF_8);
                byte[] buf = new byte[256];
                while (run) {
                    for (InetAddress a : targets(ctx)) {
                        try {
                            s.send(new DatagramPacket(probe, probe.length, a, Proto.UDP_PORT));
                        } catch (Exception ignored) {
                        }
                    }
                    long end = System.currentTimeMillis() + 2500;
                    while (run && System.currentTimeMillis() < end) {
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            s.receive(p);
                            String str = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                            if (str.startsWith(Proto.REPLY)) {
                                String[] parts = str.split("\\|");
                                final String name = parts.length > 1 ? parts[1] : "TV";
                                int prt = Proto.TCP_PORT;
                                try {
                                    if (parts.length > 2) prt = Integer.parseInt(parts[2].trim());
                                } catch (Exception ignored) {
                                }
                                final int port = prt;
                                final String ip = p.getAddress().getHostAddress();
                                main.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        listener.onFound(name, ip, port);
                                    }
                                });
                            }
                        } catch (SocketTimeoutException ignored) {
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (s != null) s.close();
            }
        }

        void shutdown() {
            run = false;
            interrupt();
        }
    }

    static List<InetAddress> targets(Context c) {
        List<InetAddress> r = new ArrayList<>();
        try {
            r.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm.getDhcpInfo();
            if (d != null && d.netmask != 0) {
                int b = (d.ipAddress & d.netmask) | ~d.netmask;
                byte[] q = {(byte) (b & 0xff), (byte) ((b >> 8) & 0xff), (byte) ((b >> 16) & 0xff), (byte) ((b >> 24) & 0xff)};
                r.add(InetAddress.getByAddress(q));
            }
        } catch (Exception ignored) {
        }
        return r;
    }

    static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
        }
        return "?";
    }
}
